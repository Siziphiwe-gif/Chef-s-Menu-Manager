import React,{useState} from 'react';
import {
  Text,
  TextInput,
  View,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from 'react-native';

import {Dropdown} from 'react-native-element-dropdown';

export default function App (){

// Forming state variables 
const [dishName ,setDishName] = useState ('');
const [description,setDescription] = useState ('');
const [course,setCourse] = useState (null);
const [price,setPrice] = useState ('');

//Feeback and menu state variables 
const [errors,setErrors] = useState ({});
const [successMessage,setSuccessMessage] = useState ('');
const [menuItems,setMenuItems] = useState ([]);

//Options displayed inside the dropdown 
const courseOptions = [
  {label:'Starter',value:'Starter'},
  {label:'Main Course',value:'Main Course'},
  {label:'Dessert',value:'Dessert'},
];

//Check whether the form contains valid information 
const validateForm = () => {
const newErrors = {}
const numericPrice = Number (price)

if (dishName.trim() === ''){
  newErrors.dishName = "Please enter dish name .";
}

if (description.trim() === ''){
  newErrors.description = 'Please enter a description.';
}

if (!course){
   newErrors.course = 'Please select a course.';
}
 
if (price.trim() === '') {
      newErrors.price = 'Please enter the price.';
} else if (!Number.isFinite(numericPrice) || numericPrice <= 0) {
      newErrors.price =
        'Please enter a valid price greater than zero.';
    }

setErrors(newErrors);

return Object.keys(newErrors).length === 0;
  };

  //Add a new menu item
  const addMenuItem = () => {
    setSuccessMessage ('') ;
    if (!validateForm()) {
      return;
    }
  

const newMenuItem = {
   id: Date.now().toString(),
   dishName : dishName.trim(),
   description : description.trim(),
   course : course,
   price : Number (price).toFixed(2),
};

//Add the new item to the existing menu
setMenuItems ((currentMenuItems) =>[ 
  ...currentMenuItems,
  newMenuItem,
]);

//confirmation feeback
 setSuccessMessage(
    `${dishName.trim()} has been added to the menu successfully.`
 );

// Clear the form
 setDishName('');
 setDescription('');
 setCourse(null);
 setPrice('');
 setErrors({});
};

 const renderForm = () => (
   <View>
    <View style={styles.header}>
      <Text style={styles.title}> Chef's Menu Manager </Text>

  <Text style={styles.subtitle}> Add and view restaurant dishes </Text >
 </View>

   <View style={styles.formCard}>
    <Text style={styles.sectionTitle}> Add Menu Item </Text>

  <Text style={styles.label}>  Dish Name </Text>

  <TextInput
   style={[ styles.input, errors.dishName ? styles.inputError : null,]}
    placeholder="Enter the dish name"
    value={dishName}
    onChangeText={(text) => { setDishName(text);
   
   setErrors((currentErrors) => ({
      ...currentErrors,
       dishName: '',
   }));
   setSuccessMessage('');
    }}
     />
  
  {errors.dishName ? (
     <Text style={styles.errorText}>
      {errors.dishName}
      </Text>
        ) : null}

 <Text style={styles.label}>  Description </Text>

 <TextInput
  style={[ styles.input,
         styles.descriptionInput,
         errors.description ? styles.inputError : null,
 ]}
   placeholder="Describe the dish"
   value={description}
   onChangeText={(text) => {  setDescription(text);

    setErrors((currentErrors) => ({
      ...currentErrors,
      description: '',
       }));

  setSuccessMessage('');

 }}
  />

    {errors.description ? (
      <Text style={styles.errorText}>
      {errors.description}
       </Text>
        ) : null}
    
  <Text style={styles.label}>  Course </Text>

 <Dropdown
  style={[ styles.dropdown, errors.course ? styles.inputError : null,
  ]}
 placeholderStyle={styles.placeholderStyle}
 selectedTextStyle={styles.selectedTextStyle}
 itemTextStyle={styles.itemTextStyle}
 data={courseOptions}
  maxHeight={200}
 labelField="label"
 valueField="value"
placeholder="Select a course"
value={course}
onChange={(item) => {
  setCourse(item.value);

setErrors((currentErrors) => ({
   ...currentErrors,
   course: '',
    }));

setSuccessMessage('');
 }}
 />

  {errors.course ? (
    <Text style={styles.errorText}>
    {errors.course}
    </Text>
     ) : null}

<Text style={styles.label}> Price </Text>

  <View
  style={[
    styles.priceContainer,
    errors.price ? styles.inputError : null,
     ]}
     >
  
  <Text style={styles.currency}>R</Text>
   <TextInput
   style={styles.priceInput}
   placeholder="Enter the price"
   value={price}
   onChangeText={(text) => {
     setPrice(text);

  setErrors((currentErrors) => ({
      ...currentErrors,
      price: '',
      }));

  setSuccessMessage('');
   }}
   keyboardType="numeric"
    />
    </View>

 {errors.price ? (
   <Text style={styles.errorText}>
     {errors.price}
     </Text>
     ) : null}

      <TouchableOpacity
       style={styles.addButton}
       onPress={addMenuItem}
       >

  <Text style={styles.addButtonText}> Add Menu Item  </Text>
  </TouchableOpacity>

   {successMessage ? (
    <View style={styles.successBox}>
    <Text style={styles.successText}>
      {successMessage}
    </Text>
  </View>
) : null}

</View>

<View style={styles.listHeading}>
<Text style={styles.sectionTitle}>Menu Items  </Text>

<View style={styles.countBadge}>
<Text style={styles.countText}>
   {menuItems.length}
</Text>
 </View>
 </View>

 </View>
   );

//Display each menu item
const renderMenuItem = ({ item }) => (
  <View style={styles.menuCard}>
 <View style={styles.menuCardHeader}>
  <Text style={styles.dishName}>
   {item.dishName}
     </Text>

<Text style={styles.menuPrice}>
R{item.price}
</Text>
 </View>

 <Text style={styles.courseLabel}>
  {item.course}
 </Text>

  <Text style={styles.menuDescription}>
   {item.description}
  </Text>
  </View>
);

return (
    <View style={styles.container}>
      <FlatList
        data={menuItems}
        keyExtractor={(item) => item.id}
        renderItem={renderMenuItem}
        ListHeaderComponent={renderForm()}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyTitle}>
              Your menu is empty
            </Text>

            <Text style={styles.emptyText}>
              Complete the form above to add your first dish.
            </Text>
          </View>
        }
        contentContainerStyle={styles.listContent}
        keyboardShouldPersistTaps="handled"
      />
    </View>
  );
  }

 const styles = StyleSheet.create({
  container : {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },

  listContent: {
    width: '100%',
    maxWidth: 600,
    alignSelf: 'center',
    padding: 16,
    paddingTop: 30,
    paddingBottom: 40,
  },


 header: {
    alignItems: 'center',
    marginBottom: 24,
  },

   title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#222222',
    textAlign: 'center',
  },

  subtitle: {
    marginTop: 6,
    fontSize: 16,
    color: '#666666',
    textAlign: 'center',
  },

  formCard: {
    padding: 18,
    borderWidth: 1,
    borderColor: '#DDDDDD',
    borderRadius: 14,
    backgroundColor: '#FFFFFF',
  },

  sectionTitle: {
    fontSize: 21,
    fontWeight: 'bold',
    color: '#222222',
  },

  label: {
    marginTop: 16,
    marginBottom: 7,
    fontWeight: '600',
    color: '#333333',
  },

input: {
  minHeight: 50,
  paddingHorizontal: 14,
  borderWidth: 1,
  borderColor: '#CCCCCC',
  borderRadius: 6,
  backgroundColor: '#FFFFFF',
  color: '#222222',
  fontSize: 16,
},

 descriptionInput: {
    minHeight: 100,
    paddingTop: 13,
  },

 inputError: {
    borderColor: '#B00020',
  },

errorText: {
    marginTop: 6,
    color: '#B00020',
    fontSize: 13,
  },

  dropdown: {
    height: 50,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderColor: '#CCCCCC',
    borderRadius: 8,
    backgroundColor: '#FFFFFF',
  },

  placeholderStyle: {
    color: '#888888',
    fontSize: 16,
  },

  selectedTextStyle: {
    color: '#222222',
    fontSize: 16,
  },

  itemTextStyle: {
    color: '#222222',
    fontSize: 16,
  },

priceContainer: {
    minHeight: 50,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#CCCCCC',
    borderRadius: 8,
    backgroundColor: '#FFFFFF',
  },

  currency: {
    paddingLeft: 14,
    color: '#333333',
    fontSize: 16,
    fontWeight: 'bold',
  },

priceInput: {
    flex: 1,
    minHeight: 48,
    paddingHorizontal: 8,
    color: '#222222',
    fontSize: 16,
  },

addButton: {
    minHeight: 50,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 22,
    borderRadius: 8,
    backgroundColor: '#2F5D3A' ,
  },

 addButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },

 successText: {
    color: '#2F5D3A',
    fontSize: 14,
    textAlign: 'center',
  },

 listHeading: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 28,
    marginBottom: 12,
  },

 successBox: {
    marginTop: 14,
    padding: 12,
    borderWidth: 1,
    borderColor: '#CCCCCC',
    borderRadius: 8,
    backgroundColor: '#FFFFFF',
  },

  countBadge: {
    minWidth: 28,
    alignItems: 'center',
    marginLeft: 10,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 14,
    backgroundColor: '#E5E5E5',
  },

  countText: {
    color: '#333333',
    fontWeight: 'bold',
  },

   menuCard: {
    marginBottom: 12,
    padding: 16,
    borderLeftWidth: 5,
    borderLeftColor: '#DDDDDD',
    borderRadius: 10,
    backgroundColor: '#FFFFFF',
  },

  menuCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },

  dishName: {
    flex: 1,
    marginRight: 12,
    color: '#222222',
    fontSize: 18,
    fontWeight: 'bold',
  },

menuDescription: {
    marginTop: 10,
    color: '#555555',
    fontSize: 15,
    lineHeight: 22,
  },

  menuPrice: {
    color: '#222222',
    fontSize: 17,
    fontWeight: 'bold',
  },

   courseLabel: {
    alignSelf: 'flex-start',
    marginTop: 8,
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 12,
    color: '#555555',
    fontSize: 13,
    fontWeight: '600',
  },

 emptyContainer: {
    alignItems: 'center',
    padding: 24,
    borderWidth: 1,
    borderColor: '#CCCCCC',
    borderStyle: 'dashed',
    borderRadius: 10,
    backgroundColor: '#FFFFFF',
  },

  emptyTitle: {
    color: '#333333',
    fontSize: 17,
    fontWeight: 'bold',
  },

  emptyText: {
    marginTop: 6,
    color: '#666666',
    fontSize: 14,
    textAlign: 'center',
  },

 });
 































   

   




          




















     






