import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  ScrollView,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';

const courseOptions = ['Starter', 'Main Course', 'Dessert'];
export default function App () {

  // Screen and menu state
  const [screen, setScreen] = useState('Home');
  const [menuItems, setMenuItems] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [deleteId, setDeleteId] = useState(null);

  // Form state
  const [dishName, setDishName] = useState('');
  const [description, setDescription] = useState('');
  const [course, setCourse] = useState('Starter');
  const [price, setPrice] = useState('');
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState('');

   // Search and filter state
  const [searchText, setSearchText] = useState('');
  const [filter, setFilter] = useState('All');

  const clearForm = () => {
    setDishName ('');
    setDescription ("");
    setCourse ('Starter');
    setPrice ('');
    setErrors ({});
    setEditingId (null);

  }

  const openAddScreen = () => {
    clearForm();
    setMessage('');
    setScreen('Form');
  };

   // Load an existing menu item into the form.
   const openEditScreen  = (item) => {
    setDishName(item.dishName);
    setDescription(item.description);
    setCourse(item.course);
    setPrice(item.price);
    setEditingId(item.id);
    setErrors({});
    setMessage('');
    setScreen('Form');
  };

  // Validate all required form fields.
  const validateForm = () => {
    const newErrors = {};
    const numericPrice = Number(price);

    if (!dishName.trim()) {
      newErrors.dishName = 'Please enter the dish name.';
    }

   if (!description.trim()) {
      newErrors.description = 'Please enter a description.';
    }

   if (!price.trim()) {
      newErrors.price = 'Please enter the price.';
    } else if (!Number.isFinite(numericPrice) || numericPrice <= 0) {
      newErrors.price = 'Please enter a valid price greater than zero.';
    }

    if (!course) {
      newErrors.course = 'Please select a course.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Add a new item or update the selected item.
  const saveMenuItem = () => {
    if (!validateForm()) {
      return;
    }

    const itemValues = {
      dishName: dishName.trim(),
      description: description.trim(),
      course,
      price: Number(price).toFixed(2),
    };

    if (editingId) {
      setMenuItems((currentItems) =>
        currentItems.map((item) =>
          item.id === editingId ? { ...item, ...itemValues } : item
        )
        );

    setMessage(`${itemValues.dishName} was updated successfully.`);
    } else {
      const newItem = {
        id: Date.now().toString(),
        ...itemValues,
      };
    
    setMenuItems((currentItems) => [...currentItems, newItem]);
      setMessage(`${itemValues.dishName} was added successfully.`);
    }

    clearForm ();
    setFilter("All");
    setScreen("Home");
  };

  //Delete selected item after confirmation
 const deleteMenuItem = (item) => {
    setMenuItems((currentItems) =>
      currentItems.filter((currentItem) => currentItem.id !== item.id)
    );
    setDeleteId(null);
    setMessage(`${item.dishName} was deleted successfully.`);
  };

  //Calculate the price of all menu items 
  const averagePrice = menuItems.length
  ? menuItems.reduce((total, item) => total + Number(item.price), 0) /
  menuItems.length
  :0 ;

 // Function for counting items in each course
 const countCourse = (selectedCourse) =>
  menuItems.filter((item) => item.course === selectedCourse).length;

  const formatPrice = (amount) =>
  `R${Number(amount).toLocaleString('en-ZA', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;

 // Apply the dish-name search and course filter together
  const filteredItems = menuItems.filter((item) => {
    const matchesSearch = item.dishName
      .toLowerCase()
      .includes(searchText.trim().toLowerCase());
    const matchesCourse = filter === 'All' || item.course === filter;
    return matchesSearch && matchesCourse;
  });

  // Reusable course and filter button
const ChoiceButton = ({
  title,
  selected,
  onPress,
}) => (
  <TouchableOpacity
    style={[
      styles.choiceButton,
      selected && styles.selectedChoice,
    ]}
    onPress={onPress}
    activeOpacity={0.7}
  >
    <Text
      style={[
        styles.choiceText,
        selected && styles.selectedChoiceText,
      ]}
    >
      {title}
    </Text>
  </TouchableOpacity>
);

  // Reusable statistics card.
  const StatisticCard = ({ title, value }) => (
    <View style={styles.statisticCard}>
      <Text style={styles.statisticTitle}>{title}</Text>
      <Text style={styles.statisticValue}>{value}</Text>
    </View>
  );

   // SCREEN 1: Statistics, search, filter and menu list.
  const HomeScreen = () => (
    <View style={styles.container}>
      <FlatList
        data={filteredItems}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.homeContent}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <View>
            <View style={styles.header}>
              <View style={styles.headerText}>
                <Text style={styles.mainTitle}>Chef's Menu Manager</Text>
              <Text style={styles.subtitle}>Manage your restaurant menu</Text>
              </View>

          <TouchableOpacity style={styles.addButton} onPress={openAddScreen}>
                <Text style={styles.addButtonText}>+ Add Menu Item</Text>
              </TouchableOpacity>
            </View>
            {message ? <Text style={styles.successMessage}>{message}</Text> : null}
            <Text style={styles.sectionTitle}>Menu Statistics</Text>

          <StatisticCard title="Total Menu Items" value={menuItems.length} />
            <StatisticCard
              title="Average Price"
              value={formatPrice(averagePrice)}
            />
            <StatisticCard title="Starters" value={countCourse('Starter')} />
            <StatisticCard
              title="Main Courses"
              value={countCourse('Main Course')}
            />
            <StatisticCard title="Desserts" value={countCourse('Dessert')} />

            <Text style={styles.sectionTitle}>Search Menu</Text>
            <TextInput
              style={styles.searchInput}
              placeholder="Search by dish name"
              placeholderTextColor="#888888"
              value={searchText}
              onChangeText={setSearchText}
            />

           <Text style={styles.sectionTitle}>Filter by Course</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.filterRow}
            >
             {['All', ...courseOptions].map((option) => (
                <ChoiceButton
                  key={option}
                  title={option}
                  selected={filter === option}
                  onPress={() => setFilter(option)}
                />
              ))}
            </ScrollView>

            <TouchableOpacity
              style={styles.clearButton}
              onPress={() => {
                setSearchText('');
                setFilter('All');
              }}
            >
          <Text style={styles.clearButtonText}>Clear Search and Filter</Text>
            </TouchableOpacity>

             <View style={styles.listHeading}>
              <Text style={styles.sectionTitle}>Menu Items</Text>
              <Text style={styles.itemCount}>
                {filteredItems.length} of {menuItems.length}
              </Text>
            </View>

            {filteredItems.length === 0 ? (
              <View style={styles.emptyCard}>
                <Text style={styles.emptyTitle}>
                  {menuItems.length === 0
                    ? 'No menu items added'
                    : 'No matching menu items'}
                </Text>

                <Text style={styles.emptyText}>
                  {menuItems.length === 0
                  ? 'Add your first dish to start creating the menu.'
                   : 'Try another search or clear the course filter.'}
                  </Text>
                {menuItems.length === 0 ? (
                  <TouchableOpacity
                   style={styles.emptyButton}
                    onPress={openAddScreen}
                  >
                    <Text style={styles.emptyButtonText}>Add First Item</Text>
                  </TouchableOpacity>
                ) : null}
              </View>
            ) : null}
          </View>
        }

        renderItem={({ item }) => (
          <View style={styles.menuCard}>
            <View style={styles.menuHeader}>
              <View style={styles.menuDetails}>
                <Text style={styles.dishName}>{item.dishName}</Text>
                <Text style={styles.description}>{item.description}</Text>
              </View>
              <View style={styles.courseBadge}>
                <Text style={styles.courseBadgeText}>{item.course}</Text>
              </View>
            </View>

            <Text style={styles.menuPrice}>{formatPrice(item.price)}</Text>

             {deleteId === item.id ? (
              <View style={styles.deleteConfirmation}>
            <Text style={styles.deleteQuestion}>Delete this menu item?</Text>
                <View style={styles.actionRow}>
                  <TouchableOpacity
                    style={styles.editButton}
                    onPress={() => setDeleteId(null)}
                  >
                    <Text style={styles.editButtonText}>Cancel</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.confirmDeleteButton}
                    onPress={() => deleteMenuItem(item)}
                  >

                  <Text style={styles.confirmDeleteText}>Confirm Delete</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ) : (
              <View style={styles.actionRow}>
                <TouchableOpacity
                  style={styles.editButton}
                  onPress={() => openEditScreen(item)}
                  >

              <Text style={styles.editButtonText}>Edit Item</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.deleteButton}
                  onPress={() => setDeleteId(item.id)}
                >

                 <Text style={styles.deleteButtonText}>Delete Item</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}
      />
    </View>
  );

   // SCREEN 2: Add a new item or edit an existing item.
    const FormScreen = () => (
    <View style={styles.container}>
      <KeyboardAvoidingView
        style={styles.screen}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.formContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.formHeader}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => {
                 clearForm();
                setScreen('Home');
              }}
            >

             <Text style={styles.backButtonText}>Back</Text>
            </TouchableOpacity>

            <Text style={styles.formTitle}>
              {editingId ? 'Edit Menu Item' : 'Add Menu Item'}
            </Text>
          </View>

           <Text style={styles.formDescription}>
            {editingId
              ? 'Update the dish information and save your changes.'
              : 'Enter the dish information and select its course.'}
          </Text>

          <View style={styles.formCard}>
            <Text style={styles.label}>
            <Text style={styles.label}>Dish name</Text>

            <TextInput
            style={[
            styles.input,
            errors.dishName && styles.inputError,
             ]}
              placeholder="Example: Pan-Seared Salmon"
             placeholderTextColor="#888888"
            value={dishName}
            onChangeText={setDishName}
            />
            {errors.dishName ? (
            <Text style={styles.errorText}>
            {errors.dishName}
            </Text>
             ) : null}
             
             <Text style={styles.label}> Description</Text>
             <TextInput
            style={[
            styles.input,
            styles.descriptionInput,
            errors.description && styles.inputError,
          ]}
          placeholder="Describe the dish"
          placeholderTextColor="#888888"
          value={description}
          multiline={true}
          textAlignVertical="top"
          onChangeText={setDescription}
        />

        {errors.description ? (
        <Text style={styles.errorText}>
        {errors.description}
        </Text>
      ) : null}

            <Text style={styles.label}>Course</Text>
            <View style={styles.courseRow}>
              {courseOptions.map((option) => (
                <ChoiceButton
                  key={option}
                  title={option}
                  selected={course === option}
                  onPress={() => setCourse(option)}
                />
              ))}
            </View>
            {errors.course ? (
              <Text style={styles.errorText}>{errors.course}</Text>
            ) : null}

             <Text style={styles.label}>Price</Text>
            <TextInput
              style={[styles.input, errors.price && styles.inputError]}
              placeholder="Enter the price"
              placeholderTextColor="#888888"
              keyboardType="decimal-pad"
              value={price}
              onChangeText={setPrice}
            />
            {errors.price ? (
              <Text style={styles.errorText}>{errors.price}</Text>
            ) : null}

             <View style={styles.selectionBox}>
              <Text style={styles.selectionLabel}>Selected course</Text>
              <Text style={styles.selectionValue}>{course}</Text>
            </View>

           <TouchableOpacity style={styles.saveButton} onPress={saveMenuItem}>
              <Text style={styles.saveButtonText}>
                {editingId ? 'Save Changes' : 'Save Menu Item'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
            style={styles.cancelButton}
            onPress={() => {
           clearForm();
            setScreen('Home');
             }}
            >
            <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
            </View>
      </ScrollView>
    </KeyboardAvoidingView>
      </View>
  );
      
                  
  return screen === 'Form' ? FormScreen() : HomeScreen();
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F5F5F5' },
  screen: { flex: 1 },
  homeContent: {
    width: '100%',
    maxWidth: 700,
    alignSelf: 'center',
    padding: 18,
     paddingBottom: 50,
  },
  header: { marginBottom: 26 },
  headerText: { marginBottom: 16 },
  mainTitle: { fontSize: 28, fontWeight: '700', color: '#222222' },
  subtitle: { fontSize: 15, color: '#666666', marginTop: 4 },
  addButton: {
    backgroundColor: '#2F5D3A',
    paddingVertical: 13,
    borderRadius: 9,
    alignItems: 'center',
  },
  addButtonText: { color: '#FFFFFF', fontSize: 15, fontWeight: '700' },
  successMessage: {
    color: '#2F5D3A',
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#2F5D3A',
    borderRadius: 8,
    padding: 11,
    marginBottom: 18,
    textAlign: 'center',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#222222',
    marginBottom: 12,
  },
  statisticCard: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#DDDDDD',
    borderRadius: 9,
    padding: 14,
    marginBottom: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
   statisticTitle: { fontSize: 15, color: '#555555' },
  statisticValue: { fontSize: 16, fontWeight: '700', color: '#222222' },
  searchInput: {
    height: 50,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#CCCCCC',
    borderRadius: 8,
    paddingHorizontal: 12,
    fontSize: 15,
    color: '#222222',
    marginBottom: 20,
  },
  filterRow: { paddingBottom: 12 },
  choiceButton: {
    backgroundColor: '#E5E5E5',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 14,
    marginRight: 7,
    minHeight: 44,
     justifyContent: 'center',
  },
  selectedChoice: { backgroundColor: '#2F5D3A' },
  choiceText: { color: '#333333', fontSize: 13, fontWeight: '700' },
  selectedChoiceText: { color: '#FFFFFF' },
  clearButton: {
    borderWidth: 1,
    borderColor: '#777777',
    borderRadius: 8,
    paddingVertical: 11,
    alignItems: 'center',
    marginBottom: 24,
  },
  clearButtonText: { color: '#333333', fontWeight: '700' },
  listHeading: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
   itemCount: { color: '#666666', marginBottom: 12 },
  menuCard: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#DDDDDD',
    borderRadius: 11,
    padding: 16,
    marginBottom: 12,
  },
   menuHeader: { flexDirection: 'row', alignItems: 'flex-start' },
  menuDetails: { flex: 1, marginRight: 10 },
  dishName: { fontSize: 18, fontWeight: '700', color: '#222222' },
description: { fontSize: 14, color: '#666666', marginTop: 5, lineHeight: 20 },
  courseBadge: {
    backgroundColor: '#E5E5E5',
    borderRadius: 14,
    paddingVertical: 5,
    paddingHorizontal: 10,
  },
   courseBadgeText: { color: '#333333', fontSize: 12, fontWeight: '700' }, menuPrice: { fontSize: 20, fontWeight: '700', color: '#222222', marginTop: 16 },
  actionRow: { flexDirection: 'row', marginTop: 15 },
  editButton: {
    flex: 1,
    backgroundColor: '#E5E5E5',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
    marginRight: 5,
  },
  editButtonText: { color: '#333333', fontWeight: '700' },
  deleteButton: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#B00020',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
    marginLeft: 5,
  },
  deleteButtonText: { color: '#B00020', fontWeight: '700' },
  deleteConfirmation: { marginTop: 10 },
  deleteQuestion: { color: '#B00020', fontWeight: '700' },
  confirmDeleteButton: {
    flex: 1,
    backgroundColor: '#B00020',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
    marginLeft: 5,
    },
  confirmDeleteText: { color: '#FFFFFF', fontWeight: '700' },
  emptyCard: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#CCCCCC',
    borderStyle: 'dashed',
    borderRadius: 11,
    padding: 26,
    alignItems: 'center',
    marginBottom: 14,
  },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: '#222222' },
  emptyText: {
    fontSize: 14,
    color: '#666666',
    textAlign: 'center',
    marginTop: 6,
    marginBottom: 18,
  },
  emptyButton: {
    backgroundColor: '#2F5D3A',
    paddingVertical: 10,
    paddingHorizontal: 18,
    borderRadius: 8,
  },
   emptyButtonText: { color: '#FFFFFF', fontWeight: '700' },
  formContent: {
    width: '100%',
    maxWidth: 700,
    alignSelf: 'center',
    padding: 18,
    paddingBottom: 50,
  },
   formHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  backButton: {
    backgroundColor: '#E5E5E5',
    paddingVertical: 9,
    paddingHorizontal: 14,
    borderRadius: 8,
    marginRight: 14,
  },
  backButtonText: { color: '#333333', fontWeight: '700' },
  formTitle: { fontSize: 24, fontWeight: '700', color: '#222222' },
  formDescription: {
    fontSize: 15,
    lineHeight: 21,
    color: '#666666',
    marginBottom: 20,
  },
  formCard: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#DDDDDD',
    borderRadius: 11,
    padding: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '700',
    color: '#333333',
    marginBottom: 7,
  },
  input: {
      minHeight: 50,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#CCCCCC',
    borderRadius: 8,
    paddingHorizontal: 12,
    fontSize: 15,
    color: '#222222',
    marginBottom: 7,
  },
   descriptionInput: { 
     minHeight: 100,
    paddingTop: 12,
    },
  inputError: { borderColor: '#B00020' },
  errorText: { color: '#B00020', fontSize: 13, marginBottom: 12 },
  courseRow: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 8 },
  selectionBox: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 12,
    marginTop: 10,
    marginBottom: 18,
  },
   selectionLabel: { fontSize: 12, color: '#666666' },
  selectionValue: {
    fontSize: 15,
    fontWeight: '700',
    color: '#2F5D3A',
    marginTop: 3,
  },
  saveButton: {
    backgroundColor: '#2F5D3A',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
  cancelButton: {
    backgroundColor: '#E5E5E5',
    paddingVertical: 13,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
  },
  cancelButtonText: { color: '#333333', fontSize: 15, fontWeight: '700' },
});





                        




       

       







  

