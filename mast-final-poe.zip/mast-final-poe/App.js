import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  ScrollView,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';

const courseOptions = ['Starter', 'Main Course', 'Dessert'];
export default function App () {

  // Screen and menu state
  const [screen, setScreen] = useState('Home');
  const [menuItems, setMenuItems] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [deleteId, setDeleteId] = useState(null);

  // Form state
  const [dishName, setDishName] = useState('');
  const [description, setDescription] = useState('');
  const [course, setCourse] = useState('Starter');
  const [price, setPrice] = useState('');
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState('');

   // Search and filter state
  const [searchText, setSearchText] = useState('');
  const [filter, setFilter] = useState('All');

  const clearForm = () => {
    setDishName ('');
    setDescription ("");
    setCourse ('Starter');
    setPrice ('');
    setErrors ({});
    setEditingId ("null");

  }

  const openAddScreen = () => {
    clearForm();
    setMessage('');
    setScreen('Form');
  };

   // Load an existing menu item into the form.
   const openEditScreen  = (item) => {
    setDishName(item.dishName);
    setDescription(item.description);
    setCourse(item.course);
    setPrice(item.price);
    setEditingId(item.id);
    setErrors({});
    setMessage('');
    setScreen('Form');
  };

  // Validate all required form fields.
  const validateForm = () => {
    const newErrors = {};
    const numericPrice = Number(price);

    if (!dishName.trim()) {
      newErrors.dishName = 'Please enter the dish name.';
    }

   if (!description.trim()) {
      newErrors.description = 'Please enter a description.';
    }

   if (!price.trim()) {
      newErrors.price = 'Please enter the price.';
    } else if (!Number.isFinite(numericPrice) || numericPrice <= 0) {
      newErrors.price = 'Please enter a valid price greater than zero.';
    }

    if (!course) {
      newErrors.course = 'Please select a course.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Add a new item or update the selected item.
  const saveMenuItem = () => {
    if (!validateForm()) {
      return;
    }

    const itemValues = {
      dishName: dishName.trim(),
      description: description.trim(),
      course,
      price: Number(price).toFixed(2),
    };

    if (editingId) {
      setMenuItems((currentItems) =>
        currentItems.map((item) =>
          item.id === editingId ? { ...item, ...itemValues } : item
        )
        );

    setMessage(`${itemValues.dishName} was updated successfully.`);
    } else {
      const newItem = {
        id: Date.now().toString(),
        ...itemValues,
      };
    
    setMenuItems((currentItems) => [...currentItems, newItem]);
      setMessage(`${itemValues.dishName} was added successfully.`);
    }

    clearForm ();
    setFilter("All");
    setScreen("Home");
  };



  

}